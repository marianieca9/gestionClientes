<?php

class Product {

    public $name;
    public $code;
    public $descr;

    public function __construct(){
        $this->name=NULL;
        $this->code=NULL;
        $this->descr=NULL;
    }

}

?>

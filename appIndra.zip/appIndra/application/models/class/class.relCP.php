<?php

class RelCP {

    public $dni_client;
    public $code_product;

    public function __construct(){
        $this->dni_client=NULL;
        $this->code_product=NULL;
    }

}

?>
